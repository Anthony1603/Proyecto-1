﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_1
{
    internal class Program
    {
        //Declaracion de Variables
         static bool Estado = true;
        static int Opcion = 0;
        static int Contador = 0;
        static int[] NumeroDePago = new int[10];
        static string[] Fecha = new string[10];
        static string[] Hora = new string[10];
        static string[] Cedula = new string[10];
        static string[] Nombre = new string[10];
        static string[] Apellido1 = new string[10];
        static string[] Apellido2 = new string[10];
        static int[] NumeroCaja = new int[10];
        static int[] TipoServicio = new int[10];
        static float[] Numerofactura = new float[10];
        static double[] MontoAPagar = new double[10];
        static double[] MontoComision = new double[10];
        static double[] MontoDeduccion = new double[10];
        static double[] MontoPagaCliente = new double[10];
        static double[] Vuelto = new double[10];
        static double[] TotalElectricidad = new double[10];
        static double[] TotalTelefono = new double[10];
        static double[] TotalAgua = new double[10];
        static int[] CantidadElectricidad = new int[10];
        static int[] CantidadAgua = new int[10];
        static int[] CantidadTelefono = new int[10];
        static void Main(string[] args)
        {
            //Titulo del Programa
            Console.WriteLine("***Aplicacion de Pago de Servicios Publicos en un Comercio***");

            //Menu del Programa
            do
            {
                Console.WriteLine("\n***Menu Principal***\n\n" +
                    "1.Inicializar Vectores \n2.Realizar pagos \n3.Consultar pagos \n4.Modificar pagos " +
                    "\n5.Eliminar pagos \n6.Submenu reportes \n7.Salir");
                Opcion = int.Parse(Console.ReadLine());

                //Condicional del Menu
                if(Opcion == 1)
                {
                    InicializarVectores();
                }
                else if (Opcion == 2)
                {
                    RealizarPagos();
                    Contador += 1;
                }
                else if (Opcion == 3)
                {
                    ConsultarPagos();
                }
                else if (Opcion == 4)
                {
                    ModificarPagos();
                }
                else if (Opcion == 5)
                {
                    EliminarPagos();
                }
                else if (Opcion == 6)
                {
                    SubmenuReportes();
                }
                else if (Opcion == 7)
                {
                    //Finalizacion del Programa
                    Console.WriteLine("Saliendo del programa...\nPresione cualquier tecla para finalizar");
                    Console.ReadKey();
                    Environment.Exit(0);
                    Estado = false;
                }
                else
                {
                    Console.WriteLine("Opcion no valida\n");
                }

            } while (Estado == true);
        }

        //Opcion 1 Inicializar los Vectores
        public static void InicializarVectores()
        {
            for (int Contador = 0; Contador < 10; Contador++)
            {
                NumeroDePago[Contador] = Contador + 1;
                Fecha[Contador] = "";
                Hora[Contador] = "";
                Cedula[Contador] = "";
                Nombre[Contador] = "";
                Apellido1[Contador] = "";
                Apellido2[Contador] = "";
                NumeroCaja[Contador] = 0;
                TipoServicio[Contador] = 0;
                Numerofactura[Contador] = 0;
                MontoAPagar[Contador] = 0;
                MontoComision[Contador] = 0;
                MontoDeduccion[Contador] = 0;
                MontoPagaCliente[Contador] = 0;
                Vuelto[Contador] =  0;
                TotalElectricidad[Contador] = 0;
                TotalAgua[Contador] = 0;
                TotalTelefono[Contador] = 0;
                CantidadElectricidad[Contador] = 0;
                CantidadAgua[Contador] = 0;
                CantidadTelefono[Contador] = 0;
            }
            Console.WriteLine("Vectores inicializados\n");
        }
        //Opcion 2 Ingresar los Datos del Pago
        private static void RealizarPagos()
        {
            Console.WriteLine("---Realizar Pago---");
            if (Contador >= 10)
            {
                Console.WriteLine("Vectores llenos");
            }
            else
            {
                //Procedimiento: Numero de Pago
                NumeroDePago[Contador] = Contador + 1;

                //Entrada de Datos: Fecha
                Console.WriteLine("Ingrese los siguientes datos para la realizacion del pago: \nFecha: ");
                Fecha[Contador] = Console.ReadLine();

                //Entrada de Datos: Hora
                Console.WriteLine("Hora: ");
                Hora[Contador] = Console.ReadLine();

                //Entrada de Datos: Cedula
                Console.WriteLine("Cedula: ");
                Cedula[Contador] = Console.ReadLine();

                //Entrada de Datos: Nombre
                Console.WriteLine("Nombre: ");
                Nombre[Contador] = Console.ReadLine();

                //Entrada de Datos:Primer Apellido
                Console.WriteLine("Primer apellido: ");
                Apellido1[Contador] = Console.ReadLine();

                //Entrada de Datos: segundo Apellido
                Console.WriteLine("Segundo apellido");
                Apellido2[Contador] = Console.ReadLine();

                //Procedimiento del Numero de Caja 
                Random NumCaja = new Random();
                NumeroCaja[Contador] = NumCaja.Next(1, 4);

                //Procedimiento del Tipo de Servicio
                do
                {
                    Console.WriteLine("Seleccione el tipo de servicio: \n1.Recibo de luz \n2.Recibo de telefono \n3.Recibo de agua");
                    TipoServicio[Contador] = int.Parse(Console.ReadLine());
                      if (TipoServicio[Contador] > 3)
                      {
                        Console.WriteLine("Opcion no valida");
                        continue;
                      }
                } while ((TipoServicio[Contador] > 3) || (TipoServicio[Contador] < 0));

                //Entrada de Datos: Numero de Factura
                Console.WriteLine("Numero de factura");
                Numerofactura[Contador] = int.Parse(Console.ReadLine());

                //Entrada de Datos: Monto a Pagar
                Console.WriteLine("Monto a pagar");
                MontoAPagar[Contador] = double.Parse(Console.ReadLine());

                //Procedimiento del Monto Comision
                if (TipoServicio[Contador] == 1)
                {
                    MontoComision[Contador] = (MontoAPagar[Contador] * 4 / 100);
                    TotalElectricidad[Contador] += MontoComision[Contador];
                    CantidadElectricidad[Contador] += 1;
                }
                else if (TipoServicio[Contador] == 2)
                {
                    MontoComision[Contador] = (MontoAPagar[Contador] * 5.5 / 100);
                    TotalTelefono[Contador] += MontoComision[Contador];
                    CantidadTelefono[Contador] += 1;
                }
                else if (TipoServicio[Contador] == 3)
                {
                    MontoComision[Contador] = (MontoAPagar[Contador] * 6.5 / 100);
                    TotalAgua[Contador] += MontoComision[Contador];
                    CantidadAgua[Contador] += 1;
                }

                //Procedimiento: Monto Deduccion
                MontoDeduccion[Contador] = MontoAPagar[Contador] - MontoComision[Contador];

                //Entrada de Datos: Monto a Pagar por el Cliente
                Console.WriteLine("Monto pagado por el cliente");
                do
                {
                    MontoPagaCliente[Contador] = double.Parse(Console.ReadLine());

                    if(MontoPagaCliente[Contador] < MontoAPagar[Contador])
                    {
                        Console.WriteLine("EL monto pagado por el cliente no puede ser menor al monto a pagar " +
                            "\nPorfavor vuelva a digitar el monto pagado por el cliente");
                    }
                } while (MontoPagaCliente[Contador] < MontoAPagar[Contador]);
              

                //Procedimiento: Vuelto
                Vuelto[Contador] = MontoPagaCliente[Contador] - MontoAPagar[Contador];
            }
        }
        //Opcion 3 Mostrar la Lista de Pagos
        private static void ConsultarPagos()
        {
            //Salida de Datos
            Console.WriteLine("---Consultar Pago---\n" +
                "Digite el numero de Pago que esta buscando: ");
            int Numero = int.Parse(Console.ReadLine());
            int BucarNumeroPago = Array.IndexOf(NumeroDePago, Numero);
            Console.WriteLine("--------------------------------------------------------------------------------------------");
            if(BucarNumeroPago != -1)
            {
                Console.WriteLine($"\nNumero de Pago: {NumeroDePago[BucarNumeroPago]}\n" +
                $"Fecha: {Fecha[BucarNumeroPago]}\t Hora: {Hora[BucarNumeroPago]}\n\n" +
                $"Cedula: {Cedula[BucarNumeroPago]}\t\t Nombre: {Nombre[BucarNumeroPago]}\n" +
                $"Primer Apellido: {Apellido1[BucarNumeroPago]}\t Segundo Apellido: {Apellido2[BucarNumeroPago]}\n\n" +
                $"Tipo de Servicio: {TipoServicio[BucarNumeroPago]}\n\n" +
                $"Numero de Factura: {Numerofactura[BucarNumeroPago]}\t Monto a Pagar: {MontoAPagar[BucarNumeroPago]}\n" +
                $"Comision Autorizada: {MontoComision[BucarNumeroPago]}\t Pagar con: {MontoPagaCliente[BucarNumeroPago]}\n" +
                $"Monto deducido: {MontoDeduccion[BucarNumeroPago]}\t\t Vuelto: {Vuelto[BucarNumeroPago]}\n" +
                $"-------------------------------------------------------------------------------------------");
            }
            else
            {
                Console.WriteLine("Pago no se encuentra registrado");
            }
        }
        //Opcion 4
        private static void ModificarPagos()
        {
            Console.WriteLine("---Modificar Pago---\n" +
               "Digite el numero de Pago que desea modificar: ");
            int Numero = int.Parse(Console.ReadLine());
            int BucarNumeroPago = Array.IndexOf(NumeroDePago, Numero);
            Console.WriteLine("--------------------------------------------------------------------------------------------");
            if (BucarNumeroPago != -1)
            {
                Console.WriteLine($"\nNumero de Pago: {NumeroDePago[BucarNumeroPago]}\n" +
                $"Fecha: {Fecha[BucarNumeroPago]}\t Hora: {Hora[BucarNumeroPago]}\n\n" +
                $"Cedula: {Cedula[BucarNumeroPago]}\t\t Nombre: {Nombre[BucarNumeroPago]}\n" +
                $"Primer Apellido: {Apellido1[BucarNumeroPago]}\t Segundo Apellido: {Apellido2[BucarNumeroPago]}\n\n" +
                $"Tipo de Servicio: {TipoServicio[BucarNumeroPago]}\n\n" +
                $"Numero de Factura: {Numerofactura[BucarNumeroPago]}\t Monto a Pagar: {MontoAPagar[BucarNumeroPago]}\n" +
                $"Comision Autorizada: {MontoComision[BucarNumeroPago]}\t Pagar con: {MontoPagaCliente[BucarNumeroPago]}\n" +
                $"Monto deducido: {MontoDeduccion[BucarNumeroPago]}\t\t Vuelto: {Vuelto[BucarNumeroPago]}\n" +
                $"-------------------------------------------------------------------------------------------");
                
                do
                {
                    Console.WriteLine("Ingrese el dato que desea cambiar:\n1-Nombre y Apellidos\n 2-Cedula\n 3-Numero de factura\n 4-Salir");
                    Opcion = int.Parse(Console.ReadLine());

                    if (Opcion == 1 && BucarNumeroPago != -1)
                    {
                        Console.WriteLine("Nombre: ");
                        Nombre[BucarNumeroPago] = Console.ReadLine();

                        Console.WriteLine("Primer apellido: ");
                        Apellido1[BucarNumeroPago] = Console.ReadLine();

                        Console.WriteLine("Segundo apellido");
                        Apellido2[BucarNumeroPago] = Console.ReadLine();
                    }
                    else if (Opcion == 2 && BucarNumeroPago != -1)
                    {
                        Console.WriteLine("Cedula: ");
                        Cedula[BucarNumeroPago] = Console.ReadLine();

                    }
                    else if (Opcion == 3 && BucarNumeroPago != -1)
                    {
                        Console.WriteLine("Numero de factura");
                        Numerofactura[BucarNumeroPago] = int.Parse(Console.ReadLine());
                    }
                    else Console.WriteLine("Opcion no valida");

                } while (Opcion==4);
            }
            else
            {
                Console.WriteLine("Pago no se encuentra registrado");
            }
        }
        //Opcion 5
        private static void EliminarPagos()
        {
            Console.WriteLine("---Eliminar Pago---\n" +
                "Digite el numero de Pago que desea eliminar: ");
            int Numero = int.Parse(Console.ReadLine());
            int BucarNumeroPago = Array.IndexOf(NumeroDePago, Numero);
            Console.WriteLine("--------------------------------------------------------------------------------------------");
            if (BucarNumeroPago != -1)
            {
                Console.WriteLine($"\nNumero de Pago: {NumeroDePago[BucarNumeroPago]}\n" +
                $"Fecha: {Fecha[BucarNumeroPago]}\t Hora: {Hora[BucarNumeroPago]}\n\n" +
                $"Cedula: {Cedula[BucarNumeroPago]}\t\t Nombre: {Nombre[BucarNumeroPago]}\n" +
                $"Primer Apellido: {Apellido1[BucarNumeroPago]}\t Segundo Apellido: {Apellido2[BucarNumeroPago]}\n\n" +
                $"Tipo de Servicio: {TipoServicio[BucarNumeroPago]}\n\n" +
                $"Numero de Factura: {Numerofactura[BucarNumeroPago]}\t Monto a Pagar: {MontoAPagar[BucarNumeroPago]}\n" +
                $"Comision Autorizada: {MontoComision[BucarNumeroPago]}\t Pagar con: {MontoPagaCliente[BucarNumeroPago]}\n" +
                $"Monto deducido: {MontoDeduccion[BucarNumeroPago]}\t\t Vuelto: {Vuelto[BucarNumeroPago]}\n" +
                $"-------------------------------------------------------------------------------------------");

                do
                {
                    Console.WriteLine("Desea eliminar este dato? 1-Si 2-No");
                    Opcion = int.Parse(Console.ReadLine());
                    if(Opcion == 1 && BucarNumeroPago != -1)
                    {
                        NumeroDePago[BucarNumeroPago] = 0;
                        Fecha[BucarNumeroPago] = "";
                        Hora[BucarNumeroPago] = "";
                        Cedula[BucarNumeroPago] = "";
                        Nombre[BucarNumeroPago] = "";
                        Apellido1[BucarNumeroPago] = "";
                        Apellido2[BucarNumeroPago] = "";
                        NumeroCaja[BucarNumeroPago] = 0;
                        TipoServicio[BucarNumeroPago] = 0;
                        Numerofactura[BucarNumeroPago] = 0;
                        MontoAPagar[BucarNumeroPago] = 0;
                        MontoComision[BucarNumeroPago] = 0;
                        MontoDeduccion[BucarNumeroPago] = 0;
                        MontoPagaCliente[BucarNumeroPago] = 0;
                        Vuelto[BucarNumeroPago] = 0;
                    }
                    else Console.WriteLine("Opcion no valida");
                } while (Opcion == 2);
            }
            else
            {
                Console.WriteLine("Pago no se encuentra registrado");
            }
        }
        //Opcion 6
        private static void SubmenuReportes()
        {
            Console.WriteLine("---Submenu de Reportes---");
            do
            {
                Console.WriteLine("1-Ver todos los pagos\n 2-Ver pagos por tipo de servicio\n " +
                    "3-Ver Pago por codigo de caja\n 4-Ver dinero comisionado por servivios\n 5-Regresar al menu principal");
                Opcion = int.Parse(Console.ReadLine());
                if (Opcion == 1)
                {
                    for (int i = 0; i <= NumeroDePago[Contador]; i++)
                    {
                        int BucarNumeroPago = Array.IndexOf(NumeroDePago, i - 1);
                        Console.WriteLine("--------------------------------------------------------------------------------------------");
                        if (BucarNumeroPago != -1)
                        {
                            Console.WriteLine($"\nNumero de Pago: {NumeroDePago[BucarNumeroPago]}\n" +
                            $"Fecha: {Fecha[BucarNumeroPago]}\t Hora: {Hora[BucarNumeroPago]}\n\n" +
                            $"Cedula: {Cedula[BucarNumeroPago]}\t\t Nombre: {Nombre[BucarNumeroPago]}\n" +
                            $"Primer Apellido: {Apellido1[BucarNumeroPago]}\t Segundo Apellido: {Apellido2[BucarNumeroPago]}\n\n" +
                            $"Tipo de Servicio: {TipoServicio[BucarNumeroPago]}\n\n" +
                            $"Numero de Factura: {Numerofactura[BucarNumeroPago]}\t Monto a Pagar: {MontoAPagar[BucarNumeroPago]}\n" +
                            $"Comision Autorizada: {MontoComision[BucarNumeroPago]}\t Pagar con: {MontoPagaCliente[BucarNumeroPago]}\n" +
                            $"Monto deducido: {MontoDeduccion[BucarNumeroPago]}\t\t Vuelto: {Vuelto[BucarNumeroPago]}\n" +
                            $"-------------------------------------------------------------------------------------------");
                        }

                    }

                }
                else if (Opcion == 2)
                {
                    int Servicio = 0;
                    do
                    {
                        Console.WriteLine("Seleccione el tipo de servicio que desea encontrar: \n1.Recibo de luz \n2.Recibo de telefono \n3.Recibo de agua");
                        Servicio = int.Parse(Console.ReadLine());
                        if (Servicio > 3)
                        {
                            Console.WriteLine("Servicio no encontrado");
                            continue;
                        }
                        Console.WriteLine("--------------------------------------------------------------------------------------------\n" +
                             "#Pago\t Fecha/Hora Pago\t Cedula\t\t Nombre\t\t Apellido1\t Apellido2\t Monto Recibido \n" +
                             "--------------------------------------------------------------------------------------------");
                        for (int i = 0; i <= NumeroDePago[Contador]; i++)
                        {
                            if (Servicio == TipoServicio[i])
                            {
                                Console.WriteLine($"{NumeroDePago[i]}\t {Fecha[i]}\t {Hora[i]}\t\t {Cedula[i]}\t {Nombre[i]}\t\t {Apellido1[i]}\t\t {Apellido2[i]}\t\t {MontoAPagar[i]}");


                            }
                        }
                        Console.WriteLine("--------------------------------------------------------------------------------------------");

                    } while ((Servicio > 3) || (Servicio < 0));
                }
                else if (Opcion == 3)
                {
                    int caja = 0;
                    do
                    {
                        Console.WriteLine("Digite el numero de la caja \"entre 1 y 3\"");
                        caja = int.Parse(Console.ReadLine());
                        if (caja > 3)
                        {
                            Console.WriteLine("Caja no encontrada");
                            continue;
                        }
                        Console.WriteLine("--------------------------------------------------------------------------------------------\n" +
                             "#Pago\t Fecha/Hora Pago\t Cedula\t\t Nombre\t\t Apellido1\t Apellido2\t Monto Recibido \n" +
                             "--------------------------------------------------------------------------------------------");
                        for (int i = 0; i <= NumeroDePago[Contador]; i++)
                        {
                            if (caja == NumeroCaja[i])
                            {
                                Console.WriteLine($"{NumeroDePago[i]}\t {Fecha[i]}\t {Hora[i]}\t\t {Cedula[i]}\t {Nombre[i]}\t\t {Apellido1[i]}\t\t {Apellido2[i]}\t\t {MontoAPagar[i]}");


                            }
                        }
                        Console.WriteLine("--------------------------------------------------------------------------------------------");

                    } while ((caja > 3) || (caja < 0));
                }
                else if (Opcion == 4)
                {
                    for (int i = 0; i <= NumeroDePago[Contador]; i++)
                    {
                        int BucarNumeroPago = Array.IndexOf(NumeroDePago, i - 1);
                        Console.WriteLine("--------------------------------------------------------------------------------------------");
                        if (BucarNumeroPago != -1)
                        {
                            Console.WriteLine("ITEM: Electricidad  Cant.Transacciones:" + CantidadElectricidad[BucarNumeroPago] + " Total Comisionado: " + TotalElectricidad[BucarNumeroPago] +
                                "\nITEM: Telefono  Cant.Transacciones: " + CantidadTelefono[BucarNumeroPago] + " Total Comisionado: " + TotalTelefono[BucarNumeroPago] +
                                  "\nITEM: Agua  Cant.Transacciones: " + CantidadAgua[BucarNumeroPago] + " Total Comisionado: " + TotalAgua[BucarNumeroPago]);
                                
                        }
                    }
                }
                else Console.WriteLine("Opcion no valida");

            } while (Opcion == 5);
        }
    }
}
